#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>

//network define
#define DATAPORT 5004
#define BUFFSIZE 5000

//frame define
#define XSIZE 180
#define YSIZE 46

#define CHOP(x) x[strlen(x) -1] = ' '
#define gotoxy(x,y) printf("\033[%d;%df",y,x);
#define colorSprint(color, var, str) sprintf(var,"\033[%dm%s\033[0m", color, str);

typedef struct carTable{
	int IDcar;
	int NoRoad;
	struct carTable *pNextNode;
} carTable;

//func
void putFrame();
void drawRoad(int, int, char, int);
void printVertRoad(int ,int, int);
void printHorizRoad(int, int, int);
void putStringInfo();
void putLogging();
void putRoadInfo();
void logPacketRecv(int );
void addNode(int , int , carTable *, int *);
void deleteNode(int , int , carTable *, int *);
carTable* findNode(int , carTable *);
carTable* findBeforeNode(int , carTable *);

//network func
void* recvRawData(void *);

enum COLOR{RED=41, GREEN=42, YELLOW=43};

//global var
char *loggingPacketRecv[10] ={NULL};
char *stringInfo[24] ={NULL};
int situationTraffic[24];

//testing func
void createRawData(char []);

int main(){
	int i;
	//var threads
	pthread_t thID_recvRawData;
	if (pthread_create(&thID_recvRawData, NULL, recvRawData, NULL) < 0) {
		perror("create error: thread for reciving raw data\n");
		exit(1);
	}
	//init code
	for(i=0;i<24;i++){
		stringInfo[i] =(char *)malloc(sizeof(char)*255);
		if(i<10)
			loggingPacketRecv[i] =(char *)malloc(sizeof(char)*255);
	}
	//printf information
	putFrame();
	while(1){
		putStringInfo();
		putRoadInfo();
		for(i=0;i<50;i++){
			putLogging();
			usleep(1000*100);
		}
		// sleep(10);
		//usleep(1000*1000);
	}
	return 0;
}

void* recvRawData(void *p) {
	int i, j;
	//var network
	struct sockaddr_in servAddr, clntAddr;
	unsigned int clntLen;
	char buf[BUFFSIZE];
	int sock_recvRdata;
	int clntSock;
	int end;
	//int option = 1;
	//setsockopt(sock_recvRdata, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));

	//
	//recv UDP socket 
	//
	//create sock
	if ((sock_recvRdata = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		puts("socket() failed");
	//init servAddr & set servAddr
	memset(&servAddr, 0, sizeof(servAddr));
	servAddr.sin_family = AF_INET;
	servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servAddr.sin_port = htons(DATAPORT);
	if(bind(sock_recvRdata, (struct sockaddr *) &servAddr, sizeof(servAddr)) < 0)
		puts("recv data bind failed");

	clntLen = sizeof(clntAddr);

	//
	//refine raw data
	//
	//var raw data
	char *flagDelete;
	int idLastCar;
	int speedCar, idRoad, idCar;
	//var infomation data
	carTable *pTableHeader;
	int countNode=0;
	int countCar[24] ={0};
	int countRecvRawData[24] ={0};
	double totalCurSpeed[24] ={0};
	double avrCurSpeed[24] ={0};
	double avrPastSpeed[24] ={0};
	//init code
	idLastCar =-1;
	pTableHeader =(carTable*)malloc(sizeof(carTable));
	pTableHeader->IDcar =-1;
	pTableHeader->pNextNode =pTableHeader;

	while (1) {
		if ((end = recvfrom(sock_recvRdata, (void *)buf, BUFFSIZE - 1, 0, (struct sockaddr*)&clntAddr, &clntLen)) < 0)
			printf("recvfrom failed\n");
		buf[end] = '\0';

		//test data
		//createRawData(buf);
		
		//refineRawData
		// tmp =strtok(buf,"!");
		// speedCar =atoi(tmp);
		// tmp =strtok(NULL,"!");
		// idRoad =atoi(tmp);
		// tmp =strtok(NULL,"!");
		// idCar =atoi(tmp);
		if (buf[0] != '\0'){
			//printf("%s\n",buf);
			speedCar =atoi(strtok(buf,"!"));
			idRoad =atoi(strtok(NULL,"!")) -1;
			idCar =atoi(strtok(NULL,"!"));
			flagDelete =strtok(NULL,"!");

			// gotoxy(148, 39);
			// printf("전%d",idLastCar);

			// if(idLastCar != idCar){
			// 	logPacketRecv(idCar);
			// 	idLastCar =idCar;
			// }
			
			// gotoxy(148, 40);
			// printf("후%d",idLastCar);
			//gotoxy(0,2);
			//printf("%s",flagDelete);
			if(flagDelete !=NULL && atoi(flagDelete) ==0){
				char *tmp="─";
				int color =0;
				deleteNode(idCar, idRoad, pTableHeader, countCar);
				sprintf(stringInfo[idRoad],"%2d %s %3.0lf %s%2.0lf \033[%dm%s\033[0m %s %3d          ",
					idRoad+1 ,"│" ,avrPastSpeed[idRoad] ,"->" ,avrCurSpeed[idRoad] ,color ,tmp ,"│", countCar[idRoad]);
				continue;
			}
			countRecvRawData[idRoad]++;
			totalCurSpeed[idRoad] +=speedCar;
			//count Node
			addNode(idCar, idRoad, pTableHeader, countCar);

			//if((t2 -t1) >3*CLOCKS_PER_SEC)
			if(j%3 ==0){
				j=0;
				char *tmp;
				int color;
				for(i =0;i<24;i++){
					if(countRecvRawData[i] != 0)
						avrCurSpeed[i] =totalCurSpeed[i]/countRecvRawData[i];
					if(avrCurSpeed[i] > avrPastSpeed[i]){
						tmp ="▼";
						color =32;
					}
					else if(avrCurSpeed[i] < avrPastSpeed[i]){
						tmp ="▲";
						color =31;
					}
					else{
						tmp ="─";
						color =0;
					}
					sprintf(stringInfo[i],"%2d %s %3.0lf %s%2.0lf \033[%dm%s\033[0m %s %3d          ",
						i+1 ,"│" ,avrPastSpeed[i] ,"->" ,avrCurSpeed[i] ,color ,tmp ,"│", countCar[i]);
					avrPastSpeed[i] = (avrPastSpeed[i] + avrCurSpeed[i])/2;
					totalCurSpeed[i] =0;
					countRecvRawData[i] =0;
					
					// 41 : 바탕색:적색
					// 42 : 바탕색:녹색
					// 43 : 바탕색:황색
					if(countCar[i] >10)
						situationTraffic[i] =41;
					else if(countCar[i] <5)
						situationTraffic[i] =42;
					else
						situationTraffic[i] =43;

					//fflush(stdout);
				}
			}
			j++;
			// strcpy(buf,"ok");
			// sendto(sock_recvRdata, buf, strlen(buf)+1,0,(struct sockaddr*)&clntAddr, clntLen);
			buf[0] = '\0';
			
			usleep(100);
		}
	}
	pthread_exit(NULL);
}
void logPacketRecv(int idCar){
	int i;
	for(i=0;i<10;i++){
		strcpy(loggingPacketRecv[10-i],loggingPacketRecv[9-i]);
	}
	sprintf(loggingPacketRecv[0], "Packet Recv from car ID: %d         ", idCar);
}
void addNode(int IDcar, int NoRoad, carTable *pTableHeader, int *countCar){
	int i;
	carTable *newNode =(carTable*)malloc(sizeof(carTable));
	newNode->IDcar =IDcar;
	newNode->NoRoad =NoRoad;
	if(pTableHeader->pNextNode->IDcar ==-1){
		//new node
		newNode->pNextNode =pTableHeader;
		pTableHeader->pNextNode =newNode;
		countCar[NoRoad]++;
		// printf("%d번 %d에 new 추가\t",IDcar ,NoRoad);
		// for(i=0;i<24;i++){
		// 	printf("%d:%d/",i,countCar[i]);
		// }
		// puts("\n");
		return;
	}
	carTable *pTmpNode =findNode(IDcar, pTableHeader);

	if(pTmpNode ==pTableHeader){
		if(pTmpNode->IDcar == IDcar)
			return;
		newNode->pNextNode =pTmpNode->pNextNode;
		pTmpNode->pNextNode =newNode;
		countCar[NoRoad]++;
		// printf("%d번 %d에 add 추가\t\t",IDcar ,NoRoad);
		// for(i=0;i<24;i++){
		// 	printf("%d:%d/",i,countCar[i]);
		// }
		// puts("\n");
		// fflush(stdout);
		return;
	}else if(pTmpNode->NoRoad !=NoRoad){
		countCar[pTmpNode->NoRoad]--;
		// printf("%d번 %d에서 삭제\t",IDcar ,pTmpNode->NoRoad);
		pTmpNode->NoRoad =NoRoad;
		countCar[NoRoad]++;
		// printf("%d번 %d 추가\t\t",IDcar ,NoRoad);
		// for(i=0;i<24;i++){
		// 	printf("%d:%d/",i,countCar[i]);
		// }
		// printf("\n");
		// fflush(stdout);
		return;
	}
	//countNode++;
	return;

	// else{
	// 	carTable *tmpNode =*pTableHeader;
	// 	for(i=0;i<countNode;i++){
	// 		if(i != 0)
	// 			tmpNode =tmpNode->pNextNode;
	// 		if(tmpNode->IDcar ==IDcar && tmpNode->NoRoad ==NoRoad)
	// 			return 0;
	// 		else if(tmpNode->IDcar == IDcar && tmpNode->NoRoad !=NoRoad){
	// 			countCar[tmpNode->NoRoad]--;
	// 			tmpNode->NoRoad =NoRoad;
	// 			countCar[NoRoad]++;
	// 			return 0;
	// 		}
	// 	}
	// 	newNode->pNextNode =tmpNode->pNextNode;
	// 	tmpNode->pNextNode =newNode;
	// 	countCar[NoRoad]++;
	// 	return 1;
	// }
}
void deleteNode(int idCar, int idRoad, carTable *pTableHeader, int *countCar){
	carTable *pTmpNode =findBeforeNode(idCar, pTableHeader);
	carTable *pDeleteNode =pTmpNode->pNextNode;
	if(countCar[pDeleteNode->NoRoad] ==0){
		printf("error - deleteNode()");
	}
	pTmpNode->pNextNode = pDeleteNode->pNextNode;
	countCar[pDeleteNode->NoRoad]--;
	//printf("%d차량 노드 삭제, 이전 경로 %d\n",pDeleteNode->IDcar, pDeleteNode->NoRoad);
	free(pDeleteNode);
}
carTable* findNode(int IDcar, carTable *pTableHeader){
	carTable *pTmp =pTableHeader->pNextNode;
	do{
		if(pTmp->IDcar == IDcar)
			return pTmp;
		pTmp =pTmp->pNextNode;
	}while(pTmp !=pTableHeader);
	return pTmp;
}
//find right before car ID that sended as argument
carTable* findBeforeNode(int IDcar, carTable *pTableHeader){
	carTable *pTmp =pTableHeader->pNextNode;
	do{
		if(pTmp->pNextNode->IDcar == IDcar)
			return pTmp;
		pTmp =pTmp->pNextNode;
	}while(pTmp !=pTableHeader);
	return pTmp;
}
void createRawData(char buf[]){
	int s=rand()%80, r=rand()%24, ID_car=rand()%100;
	char *tmpS =(char *)malloc(sizeof(char)*255);
	sprintf(tmpS,"%d!%d!%d!",s,r, ID_car);
	strcpy(buf,tmpS);
}
void putRoadInfo(){
	//first vertical road
	drawRoad(49,4,'v',situationTraffic[0]);
	drawRoad(50,4,'v',situationTraffic[0]);
	drawRoad(49,19,'v',situationTraffic[10]);
	drawRoad(50,19,'v',situationTraffic[10]);
	drawRoad(49,34,'v',situationTraffic[20]);
	drawRoad(50,34,'v',situationTraffic[20]);
	drawRoad(52,4,'v',situationTraffic[1]);
	drawRoad(53,4,'v',situationTraffic[1]);
	drawRoad(52,19,'v',situationTraffic[11]);
	drawRoad(53,19,'v',situationTraffic[11]);
	drawRoad(52,34,'v',situationTraffic[21]);
	drawRoad(53,34,'v',situationTraffic[21]);
	//second vertical road
	drawRoad(94,4,'v',situationTraffic[2]);
	drawRoad(95,4,'v',situationTraffic[2]);
	drawRoad(94,19,'v',situationTraffic[12]);
	drawRoad(95,19,'v',situationTraffic[12]);
	drawRoad(94,34,'v',situationTraffic[22]);
	drawRoad(95,34,'v',situationTraffic[22]);
	drawRoad(97,4,'v',situationTraffic[3]);
	drawRoad(98,4,'v',situationTraffic[3]);
	drawRoad(97,19,'v',situationTraffic[13]);
	drawRoad(98,19,'v',situationTraffic[13]);
	drawRoad(97,34,'v',situationTraffic[23]);
	drawRoad(98,34,'v',situationTraffic[23]);
	//first horizontal
	drawRoad(9,18,'h',situationTraffic[4]);
	drawRoad(54,18,'h',situationTraffic[5]);
	drawRoad(99,18,'h',situationTraffic[6]);
	drawRoad(9,19,'h',situationTraffic[7]);
	drawRoad(54,19,'h',situationTraffic[8]);
	drawRoad(99,19,'h',situationTraffic[9]);
	//second horizontal
	drawRoad(9,33,'h',situationTraffic[14]);
	drawRoad(54,33,'h',situationTraffic[15]);
	drawRoad(99,33,'h',situationTraffic[16]);
	drawRoad(9,34,'h',situationTraffic[17]);
	drawRoad(54,34,'h',situationTraffic[18]);
	drawRoad(99,34,'h',situationTraffic[19]);
}
void putLogging(){
	int i;
	struct tm *t;
	time_t timer;
	// for(i=0;i<10;i++){
	// 	if(loggingPacketRecv[i] ==NULL)
	// 		continue;
	// 	gotoxy(148, 33+i);
	// 	printf("%s",loggingPacketRecv[10-i]);
	// }

	timer =time(NULL);
	t =localtime(&timer);
	gotoxy(155,47);
	printf("%3d:%3d:%3d", t->tm_hour, t->tm_min, t->tm_sec);
	fflush(stdout);
}
void putStringInfo(){
	int i;

	for(i=0;i<24;i++){
		gotoxy(148,7 +i);
		printf("%s",stringInfo[i]);
	}
	gotoxy(142,7+24);
	printf("────────────────────────────────────────────");
}
void drawRoad(int x, int y, char which, int color){
	switch(which){
		case 'v':
		printVertRoad(x,y,color);
		break;
		case 'h':
		printHorizRoad(x,y,color);
		break;
		default:
		puts("drawRoad error");
	}
}
void printVertRoad(int x, int y, int color){
	int i;
	for(i=0;i<YSIZE/3-2;i++){
		gotoxy(x,y+i+1);
		printf("\033[%dm│\033[0m",color);
	}
}
void printHorizRoad(int x, int y, int color){
	int i;
	gotoxy(x,y);
	for(i=0;i<XSIZE/4-5;i++)
		printf("\033[%dm─\033[0m",color);
	gotoxy(0,0);
	fflush(stdout);
}
void putFrame(){
	//draw frame
	int x=5,y=3;
	int i;

	system("clear");
	gotoxy(x,y);
	printf("┌");
	for(i=0;i<XSIZE;i++){
		if(i == XSIZE*3/4)
			printf("┬");
		else
			printf("─");
	}
	printf("┐");

	for(i=0;i<YSIZE;i++){
		y++;
		gotoxy(x,y);
		printf("│");

		x +=XSIZE*3/4+1;
		gotoxy(x,y);
		printf("│");

		x +=XSIZE/4;
		gotoxy(x,y);
		printf("│");
		x =5;
	}

	gotoxy(x,y);
	printf("└");
	for(i=0;i<XSIZE;i++){
		if(i == XSIZE*3/4)
			printf("┴");
		else
			printf("─");
	}
	printf("┘");
	gotoxy(145,4);
	printf("      │ Speed      │            ");
	gotoxy(145,5);
	printf("route │ past->now  │ Car        ");
	gotoxy(142,6);
	printf("────────────────────────────────────────────");

	//vertical route numbering
	gotoxy(40,6);
	printf("1 route");
	gotoxy(55,6);
	printf("2 route");
	gotoxy(84,6);
	printf("3 route");
	gotoxy(101,6);
	printf("4 route");
	gotoxy(40,25);
	printf("11 route");
	gotoxy(55,25);
	printf("12 route");
	gotoxy(84,25);
	printf("13 route");
	gotoxy(101,25);
	printf("14 route");
	gotoxy(40,46);
	printf("21 route");
	gotoxy(55,46);
	printf("22 route");
	gotoxy(84,46);
	printf("23 route");
	gotoxy(101,46);
	printf("24 route");


	// 9,18,'h',situationTraffic[4]);
	// drawRoad(9,19,'h',situationTraffic[5]);
	// drawRoad(54,18,'h',situationTraffic[6]);
	// drawRoad(54,19,'h',situationTraffic[7]);
	// drawRoad(99,18,'h',situationTraffic[8]);
	// drawRoad(99,19


	// 	9,33,'h',situationTraffic[14]);
	// drawRoad(9,34,'h',situationTraffic[15]);
	// drawRoad(54,33,'h',situationTraffic[16]);
	// drawRoad(54,34,'h',situationTraffic[17]);
	// drawRoad(99,33,'h',situationTraffic[18]);
	// drawRoad(99,34,
	//horizontal route numbering
	gotoxy(9,17);
	printf("5 route");
	gotoxy(68,17);
	printf("6 route");
	gotoxy(130,17);
	printf("7 route");
	gotoxy(9,20);
	printf("8 route");
	gotoxy(68,20);
	printf("9 route");
	gotoxy(130,20);
	printf("10 route");
	gotoxy(9,32);
	printf("15 route");
	gotoxy(68,32);
	printf("16 route");
	gotoxy(130,32);
	printf("17 route");
	gotoxy(9,35);
	printf("18 route");
	gotoxy(68,35);
	printf("19 route");
	gotoxy(130,35);
	printf("20 route");
}