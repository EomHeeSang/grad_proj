package simulation;

import java.io.*;
import java.net.*;

public class SendSocket {
	final int PORT = 5004;
	Socket sock_;
	BufferedOutputStream ostream;
	InetAddress addr_s;
	String str;
	DatagramSocket dsock = null;
	DatagramPacket dpack = null;
	byte[] buf;

	public SendSocket() {
		str = null;
		try {
			addr_s = InetAddress.getByName("192.168.35.163");
			// sock_ = new Socket(addr_s, PORT);
			dsock = new DatagramSocket();
			//System.out.println(addr_s);

		} catch (Exception e) {
			System.out.println("에러");
		}
	}

	public void setCarInfo(String CarInfo) {
		str = CarInfo;
		
		sendData();
	}

	public void sendData() {
		
			try {
				if (str != null) {
					
					buf = str.getBytes();
					dpack = new DatagramPacket(buf, buf.length, addr_s, PORT);
					
					dsock.send(dpack);
					
					//System.out.println("send");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
}