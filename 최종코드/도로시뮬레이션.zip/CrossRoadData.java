package simulation;

import java.awt.*;
import java.util.*;
import java.util.concurrent.*;

//IS: interSection
public class CrossRoadData {
   static final int IS_ROW =4;
   static final int IS_COLUMN =4;
   //각 교차로 객체
   private RoadData interSection[][];
   
   private final Semaphore sph;
   
   public CrossRoadData(){
      interSection =new RoadData[IS_ROW][IS_COLUMN];
      for(int i=0; i<IS_ROW; i++){
         for(int j=0; j<IS_COLUMN; j++){
            //각 교차로 큐 데이터 클래스
            interSection[i][j] =new RoadData(i*10 +j);
         }
      }
      sph =new Semaphore(1);
   }
   //Queue information {IS id, current Road & Road No}
   public class QueueData{
      public Point idIS;
      public char currentRoad;
      public int currentRoadNo;
      
      public QueueData(){
         idIS =new Point(0,0);
         currentRoad ='+';
         currentRoadNo =-1;
      }
   }
   public class CurrentCarEnvironment{
      public Car frontCar;
      //public int numCurrentIS;
      public Point idIS;
      public char currentRoad;
      public int innerISNumsCar;
      public char innerISOccupier;
      public CurrentCarEnvironment(){
         frontCar =null;
      }
   }
   //interface to Car
   public CurrentCarEnvironment registNewCar(Car cID, int sPoint){
      //System.out.println("registering new car");
      CurrentCarEnvironment tmpCEnviro =new CurrentCarEnvironment();
      switch(sPoint){
      case 1:
         //if start road is not empty
         if(!interSection[1][1].road[0].isEmpty())
            //get last car
            tmpCEnviro.frontCar =interSection[1][1].road[0].getLast();
         //add car which send signal
         interSection[1][1].road[0].add(cID);
         return tmpCEnviro;
      case 2:
         if(!interSection[2][1].road[0].isEmpty())
            tmpCEnviro.frontCar =interSection[2][1].road[0].getLast();
         interSection[2][1].road[0].add(cID);
         return tmpCEnviro;
      case 3:
         if(!interSection[2][1].road[1].isEmpty())
            tmpCEnviro.frontCar =interSection[2][1].road[1].getLast();
         interSection[2][1].road[1].add(cID);
         return tmpCEnviro;
      case 4:
         if(!interSection[2][2].road[1].isEmpty())
            tmpCEnviro.frontCar =interSection[2][2].road[1].getLast();
         interSection[2][2].road[1].add(cID);
         return tmpCEnviro;
      case 5:
         if(!interSection[2][2].road[2].isEmpty())
            tmpCEnviro.frontCar =interSection[2][2].road[2].getLast();
         interSection[2][2].road[2].add(cID);
         return tmpCEnviro;
      case 6:
         if(!interSection[1][2].road[2].isEmpty())
            tmpCEnviro.frontCar =interSection[1][2].road[2].getLast();
         interSection[1][2].road[2].add(cID);
         return tmpCEnviro;
      case 7:
         if(!interSection[1][2].road[3].isEmpty())
            tmpCEnviro.frontCar =interSection[1][2].road[3].getLast();
         interSection[1][2].road[3].add(cID);
         return tmpCEnviro;
      case 8:
         if(!interSection[1][1].road[3].isEmpty())
            tmpCEnviro.frontCar =interSection[1][1].road[3].getLast();
         interSection[1][1].road[3].add(cID);
         return tmpCEnviro;
      }
      System.out.println("error at registNewCar method");
      return null;
   }
   public CurrentCarEnvironment getInfomationIntersection(Car idCar){
      CurrentCarEnvironment cEnviro =new CurrentCarEnvironment();
      QueueData dataQ =new QueueData();
      if(findCurrentQueue(dataQ, idCar) ==-1)
         System.out.println("error getInformatioinIS::findCurrentQ");
      cEnviro.innerISNumsCar =interSection[dataQ.idIS.x][dataQ.idIS.y].getSema();
      cEnviro.innerISOccupier =interSection[dataQ.idIS.x][dataQ.idIS.y].getOccupier();
      
      return cEnviro;
   }
   //interface to car in side road
   public CurrentCarEnvironment recvPassSignal(Car cID, char nextRoute){
      //var
      CurrentCarEnvironment cEnviro =new CurrentCarEnvironment();
      QueueData qData =new QueueData();
      try {
         sph.acquire();
      } catch (InterruptedException e) {
         e.printStackTrace();
      }
      if(findCurrentQueue(qData, cID) == -1)
         System.out.println("findCurrentQueue error");
      if((offerNextQueue(qData, cID, cEnviro, nextRoute)) ==-1)
         System.out.println("offerNextQueue error");
      interSection[qData.idIS.x][qData.idIS.y].increaseInnerCar();
      if(interSection[qData.idIS.x][qData.idIS.y].getOccupier() != qData.currentRoad){
         interSection[qData.idIS.x][qData.idIS.y].setOccupier(qData.currentRoad);
         System.out.println("교차로" +qData.idIS.x +qData.idIS.y +"을" +qData.currentRoad +"가 점령");
      }
      cEnviro.innerISNumsCar =interSection[qData.idIS.x][qData.idIS.y].getSema();
      cEnviro.innerISOccupier =interSection[qData.idIS.x][qData.idIS.y].getOccupier();
      sph.release();
      return cEnviro;
   }
   public int findCurrentQueue(QueueData qData, Car cID){
      //findCurrentQueue
      for(int i=0; i<4; i++){
         for(int j=0; j<4; j++){
            interSection[i][j].findQueue(cID, qData);
            if(qData.currentRoad != '+'){
               qData.idIS.setLocation(i,j);
               break;
            }
         }
         if(qData.currentRoad != '+')
            break;
      }
      if(qData.currentRoad == '+' || qData.currentRoadNo == -1){
         return -1;
      }
      //System.out.println("IS location:" + qData.idIS.x + "," + qData.idIS.y);
      return 0;
   }
   //inner queue methods
   {
//   public void offerNextInnerQueue(QueueData tmpC, Car cID, CurrentCarEnvironment tmpEnviro){
//      switch(tmpC.rID[1]){
//      case 'i':
//         switch(tmpC.rID[0]){
//         case 'n':
//            if(!interSection[(int)tmpC.idIS.getX()][(int)tmpC.idIS.getY()].innerroad[0][0].isEmpty())
//                tmpEnviro.frontCar =interSection[(int)tmpC.idIS.getX()][(int)tmpC.idIS.getY()].innerroad[0][0].poll();
//            else tmpC =null;
//            interSection[(int)tmpC.idIS.getX()][(int)tmpC.idIS.getY()].innerroad[0][0].offer(cID);
//            break;
//         case 'w':
//         case 's':
//         case 'e':
//         default:
//            System.out.println("rID[0] error");
//         }
//         break;
//      case 'o':
//         break;
//      default:
//         System.out.println("rID[1] error");
//      }
//   }
   //interface to car at inner road
//   public CurrentCarEnvironment recvPassInnerSignal(Car cID, char nextRoute){
//      CurrentCarEnvironment cEnviro =new CurrentCarEnvironment();
//      QueueData qData =new QueueData();
//      cEnviro.numCurrentIS =findCurrentInnerQueue(qData, cID);
//      if(cEnviro.numCurrentIS == -1)
//         System.out.println("findCurrentQueue error");
//      offerNextInnerQueue(qData, cID, cEnviro);
//      return cEnviro;
//   }
//   public int findCurrentInnerQueue(QueueData qData, Car cID){
//      //findCurrentQueue
//      for(int i=0; i<2; i++){
//         for(int j=0; j<2; j++){
//            qData.rID =interSection[i][j].findInnerQueue(cID);
//            if(qData.rID[0] != '+')
//               break;
//         }
//         if(qData.rID[0] != '+')
//            break;
//      }
//      System.out.println("crossID:x-" +qData.idIS.getX() +",y-" +qData.idIS.getY()
//            +"road" +qData.rID[0] +qData.rID[1]);
//      
//      return -1;
//   }
   }
   public int offerNextQueue(QueueData qData, Car cID, CurrentCarEnvironment tmpEnviro, char nextRoute){
      LinkedList<Car> currentRoad =interSection[qData.idIS.x][qData.idIS.y].road[qData.currentRoadNo];
      
      currentRoad.remove(cID);
      if(!currentRoad.isEmpty())
         currentRoad.getFirst().removeFrontCar();

      RoadData nextIS =null;
      int nextQueue =-1;
      switch(nextRoute){
      case 'n':
         nextIS =interSection[qData.idIS.x][qData.idIS.y-1];
         nextQueue =2;
         break;
      case 'w':
         nextIS =interSection[qData.idIS.x-1][qData.idIS.y];
         nextQueue =1;
         break;
      case 's':
         nextIS =interSection[qData.idIS.x][qData.idIS.y+1];
         nextQueue =0;
         break;
      case 'e':
         nextIS =interSection[qData.idIS.x+1][qData.idIS.y];
         nextQueue =3;
         break;
      }
      if(!nextIS.road[nextQueue].isEmpty())
         tmpEnviro.frontCar =nextIS.road[nextQueue].getLast();
      if(tmpEnviro.frontCar !=null)
         System.out.println("앞차량 id:" + tmpEnviro.frontCar.getCarId());
      nextIS.road[nextQueue].add(cID);
      //System.out.println("교차로 " +qData.idIS.x + qData.idIS.y +"의  " +qData.currentRoadNo +"에서");
      //System.out.println("교차로 " +nextIS.idIS +"의 " +nextQueue +"로 차량 이동됨" );
      //System.out.println("queue changed" + qData.currentRoad + "->" + nextRoute);
      return 0;
      
      /*switch(qData.currentRoad){
      case 'n':
         switch(nextRoute){
         case 'w':
            currentRoad.remove(cID);
            if(!currentRoad.isEmpty())
               currentRoad.getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x+1][qData.idIS.y].road[3].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x+1][qData.idIS.y].road[3].getLast();
            interSection[qData.idIS.x+1][qData.idIS.y].road[3].add(cID);
            System.out.println("queue changed n->w");
            return 0;
         case 's':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x][qData.idIS.y+1].road[0].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x][qData.idIS.y+1].road[0].getLast();
            interSection[qData.idIS.x][qData.idIS.y+1].road[0].add(cID);
            System.out.println("queue changed n->s");
            return 0;
         case 'e':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x-1][qData.idIS.y].road[1].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x-1][qData.idIS.y].road[1].getLast();
            interSection[qData.idIS.x-1][qData.idIS.y].road[1].add(cID);
            System.out.println("queue changed n->e");
            return 0;
         }
      case 'w':
         switch(nextRoute){
         case 'n':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x][qData.idIS.y-1].road[2].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x][qData.idIS.y-1].road[2].getLast();
            interSection[qData.idIS.x][qData.idIS.y-1].road[2].add(cID);
            System.out.println("queue changed w->n");
            return 0;
         case 's':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x][qData.idIS.y+1].road[0].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x][qData.idIS.y+1].road[0].getLast();
            interSection[qData.idIS.x][qData.idIS.y+1].road[0].add(cID);
            System.out.println("queue changed w->s");
            return 0;
         case 'e':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x-1][qData.idIS.y].road[1].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x-1][qData.idIS.y].road[1].getLast();
            interSection[qData.idIS.x-1][qData.idIS.y].road[1].add(cID);
            System.out.println("queue changed w->e");
            return 0;
         }
      case 's':
         switch(nextRoute){
         case 'n':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x][qData.idIS.y-1].road[2].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x][qData.idIS.y-1].road[2].getLast();
            interSection[qData.idIS.x][qData.idIS.y-1].road[2].add(cID);
            System.out.println("queue changed w->n");
            return 0;
         case 'w':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x+1][qData.idIS.y].road[3].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x+1][qData.idIS.y].road[3].getLast();
            interSection[qData.idIS.x+1][qData.idIS.y].road[3].add(cID);
            System.out.println("queue changed");
            return 0;
         case 'e':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x-1][qData.idIS.y].road[1].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x-1][qData.idIS.y].road[1].getLast();
            interSection[qData.idIS.x-1][qData.idIS.y].road[1].add(cID);
            System.out.println("queue changed s->e");
            return 0;
         }
      case 'e':
         switch(nextRoute){
         case 'n':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x][qData.idIS.y-1].road[2].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x][qData.idIS.y-1].road[2].getLast();
            interSection[qData.idIS.x][qData.idIS.y-1].road[2].add(cID);
            System.out.println("queue changed w->n");
            return 0;
         case 'w':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x+1][qData.idIS.y].road[3].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x+1][qData.idIS.y].road[3].getLast();
            interSection[qData.idIS.x+1][qData.idIS.y].road[3].add(cID);
            System.out.println("queue changed");
            return 0;
         case 's':
            interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].remove(cID);
            if(!interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].isEmpty())
               interSection[qData.idIS.x][qData.idIS.y].road[qData.currentQueue].getFirst().removeFrontCar();
            if(!interSection[qData.idIS.x][qData.idIS.y+1].road[0].isEmpty())
               tmpEnviro.frontCar =interSection[qData.idIS.x][qData.idIS.y+1].road[0].getLast();
            interSection[qData.idIS.x][qData.idIS.y+1].road[0].add(cID);
            System.out.println("queue changed e->s");
            return 0;
         }
      }
      return -1;*/
   }
   
   public void recvInnerPassSignal(Car cID){
      QueueData tmpQdata =new QueueData();
      findCurrentQueue(tmpQdata, cID);
      RoadData currentIS =interSection[tmpQdata.idIS.x][tmpQdata.idIS.y];
      currentIS.decreaseInnerCar();
   }
   public void deregisterCar(Car carID){
      QueueData tmpQdata =new QueueData();
      findCurrentQueue(tmpQdata, carID);
      LinkedList<Car> currentRoad =interSection[tmpQdata.idIS.x][tmpQdata.idIS.y].road[tmpQdata.currentRoadNo];
      
      currentRoad.remove(carID);
      if(!currentRoad.isEmpty())
         currentRoad.getFirst().removeFrontCar();
   }
   //inner classes
   public class RoadData{
      private int idIS;
      //road*4
      private LinkedList<Car>[] road =new LinkedList[4];
      
      //inner semaphore
      private int semaphore;
      private char occupier;
      
      public RoadData(int idInterSection){
         idIS =idInterSection;
         for(int i=0; i<4; i++)
            road[i] =new LinkedList<Car>();
         semaphore =0;
         occupier ='x';
      }
      
      public void findQueue(Car cID, QueueData qData){
         for(int i=0; i<4; i++){
            if(road[i].contains(cID)){
               switch(i){
               case 0:
                  qData.currentRoad ='n';
                  qData.currentRoadNo =0;
                  break;
               case 1:
                  qData.currentRoad ='e';
                  qData.currentRoadNo =1;
                  break;
               case 2:
                  qData.currentRoad ='s';
                  qData.currentRoadNo =2;
                  break;
               case 3:
                  qData.currentRoad ='w';
                  qData.currentRoadNo =3;
                  break;
               }
            }
         }
      }
      public int getSema(){
         return semaphore;
      }
      public void increaseInnerCar(){
         semaphore++;
      }
      public void decreaseInnerCar(){
         semaphore--;
      }
      public char getOccupier(){
         return occupier;
      }
      public void setOccupier(char ocp){
         switch(ocp){
         case 'n':
            ocp ='s';
            break;
         case 'e':
            ocp ='w';
            break;
         case 's':
            ocp ='n';
            break;
         case 'w':
            ocp ='e';
            break;
         }
      }
   }
}