package simulation;

import java.awt.Point;
import java.util.Timer;
import java.util.TimerTask;

import simulation.CrossRoadData.CurrentCarEnvironment;

public class Car extends Thread {
	private Car frontCar;							// 앞차량 정보
	private CrossRoadData crd;						// 도로 데이터
	private CurrentCarEnvironment curCarEnv;		// 현재 차량 환경
	private Point start; 							// 차의 출발지
	private Point finish; 							// 차의 목적지
	private Point p; 								// 현재 차의 위치를 저장
	private int speed; 								// 차량의 현재 속도 (0 ~ 5)
	private int carId;								// 차량의 번호
	private boolean isStopped; 						// 차량이 정지했는지
	private boolean isFinished; 					// 차량이 목적지에 도착했는지
	private boolean isPassed; 						// 차량이 교차로를 통과했는지
	private boolean isChecked; 						// 차량이 교차로 통과 메시지를 보냈는지
	private char[] route;							// 차량의 경로
	private SendSocket sendSocket;					// 차량 데이터 전송 소켓
	private String carInfo; 						// 서버로 보낼 차량의 정보
	private Signal[] sig;							// 신호 정보
	
	// 자동차 출발지 _p , 목적지 _r
	public Car(int id, int _p, int _r, char[] _route, Signal[] _sig, CrossRoadData _crd) {

		// 출발지를 토대로 생성좌표 저장
		switch (_p) {
		case 1:
			p = new Point(625, 0);
			break;
		case 2:
			p = new Point(1282, 0);
			break;
		case 3:
			p = new Point(1920, 345);
			break;
		case 4:
			p = new Point(1920, 722);
			break;
		case 5:
			p = new Point(1302, 1080);  
			break;
		case 6:
			p = new Point(645, 1080);
			break;
		case 7:
			p = new Point(0, 742);
			break;
		case 8:
			p = new Point(0, 365);
			break;
		}

		// 목적지를 토대로 목적지 좌표 저장
		switch (_r) {
		case 1:
			finish = new Point(625, 0);
			break;
		case 2:
			finish = new Point(1282, 0);
			break;
		case 3:
			finish = new Point(1920, 345);
			break;
		case 4:
			finish = new Point(1920, 722);
			break;
		case 5:
			finish = new Point(1292, 1080);
			break;
		case 6:
			finish = new Point(645, 1080);
			break;
		case 7:
			finish = new Point(0, 742);
			break;
		case 8:
			finish = new Point(0, 365);
			break;
		}

		frontCar = null;
		isPassed = false;
		isChecked = false;
		isFinished = false;
		carId = id;
		start = p;
		route = _route;
		sig = _sig;
		crd = _crd;
		speed = 0;

		// 도로 데이터에 차량 등록 (반환값 : 차량의 현재 상황)
		curCarEnv = crd.registNewCar(this, _p);
		// 앞차 정보 저장
		frontCar = curCarEnv.frontCar;
		
		// 차량 정보 송신 소켓 
		sendSocket = new SendSocket();
		//sendSocket.start();
	}
	
	// 차량의 속도를 일정 주기로 올려주기 위한 타이머 설정
	Timer m_timer = new Timer();
	
	TimerTask m_task = new TimerTask() {
		
		@Override
		public void run () {
			if(speed < 3) {
				//System.out.println("스피드 증가");
				speed++;
				//System.out.println("-------증가스피드 : " + speed);
			}
		}
	};
	
	Timer send_timer = new Timer();
	
	TimerTask send_task = new TimerTask() {
		
		@Override
		public void run () {
			if(carInfo != null) 
				sendSocket.setCarInfo(carInfo);
		}
	};

	// 현재 차량 객체 반환
	public Car getCar() {
		return this;
	}

	// 현재 위치를 이동
	private void move(int _x, int _y) {
		p.setLocation(_x, _y);
	}

	// 현재 위치 반환 (x, y)
	public Point getPosition() {
		return p;
	}

	// 차량의 id 반환
	public int getCarId() {
		return carId;
	}

	// 차량이 목적지에 도착했는지
	public boolean isFinished() {
		return isFinished;
	}

	// 차량이 정지했는지
	public boolean isStopped() {
		return isStopped;
	}

	// 앞차량 정보 얻음
	public void getFrontCar(Car c) {
		frontCar = c;
	}

	// 앞차량 제거
	public void removeFrontCar() {
		frontCar = null;
	}
	

	// 서버로 보낼 차량의 데이터 반환
	public String getCarStat(char route, Point p) {
		int roadNo = 0;
		
		if (p.x <= 657 && p.y <= 343) {
			 if (route == 's')
				 roadNo = 1;
			 
			 else if (route == 'n')
				 roadNo = 2;
		}
			
		if (p.x >= 1280 && p.y <= 343) {
			if (route == 's')
				roadNo = 3;
			
			else if(route == 'n')
				roadNo = 4;
		}
		
		if (p.x >= 1314 && p.y <= 377) {
			if (route == 'w')
				roadNo = 7;
			
			else if(route == 'e')
				roadNo = 10;
		}
		
		if (p.x >= 1314 && p.y >= 720) {
			if (route == 'w')
				roadNo = 17;
			
			else if(route == 'e')
				roadNo = 20;
		}
		
		if (p.x >= 1280 && p.y >= 754) {
			if (route == 's')
				roadNo = 23;
			
			else if(route == 'n')
				roadNo = 24;
		}
		
		if (p.x <= 657 && p.y >= 754) {
			if (route == 's')
				roadNo = 21;
			
			else if(route == 'n')
				roadNo = 22;
		}
		
		if (p.x <= 623 && p.y >= 720) {
			if (route == 'w')
				roadNo = 15;
			
			else if(route == 'e')
				roadNo = 18;
		}
		
		if (p.x <= 623 && p.y <= 377) {
			if (route == 'w')
				roadNo = 5;
			
			else if(route == 'e')
				roadNo = 8;
		}
		
		if (p.x >= 657 && p.x <= 1280 && p.y <= 377) {
			if (route == 'w')
				roadNo = 6;
			
			else if(route == 'e')
				roadNo = 9;
		}
		
		if (p.x >= 657 && p.x <= 1280 && p.y >= 720) {
			if (route == 'w')
				roadNo = 16;
			
			else if(route == 'e')
				roadNo = 19;
		}
		
		if (p.x <= 657 && p.y >= 377 && p.y <= 720) {
			if (route == 's')
				roadNo = 11;
			
			else if(route == 'n')
				roadNo = 12;
		}
		
		if (p.x >= 1280 && p.y >= 377 && p.y <= 720) {
			if (route == 's')
				roadNo = 13;
			
			else if(route == 'n')
				roadNo = 14;
		}
		
		carInfo = speed*18 + "!" + roadNo + "!" + carId + "!";

		if(isFinished == true) {
			carInfo = speed*18 + "!" + roadNo + "!" + carId + "!" + "0" + "!";
			System.out.println(carInfo);
		}
		
		//System.out.println(carInfo);

		if(roadNo == 0)
			carInfo = null;
		
		return carInfo;
	}
	
	// 차량의 신호 요구... cRoute = 현재 차량 이동방향, nRoute = 사거리 통과 후 차량 이동방향
	public void requestSig(Signal[] sig, char cRoute, char nRoute, Point p) {

		for (int i = 0; i < 4; i++) {
			
			// 일정 거리 이상 근접한 신호등의 영향을 받음
			if (Math.abs(sig[i].getLocation().x - p.x) <= 25 && Math.abs(sig[i].getLocation().y - p.y) <= 25) {
				
				// 현재 교차로 내부 상황 파악
				curCarEnv = crd.getInfomationIntersection(this);
				if (curCarEnv.innerISNumsCar > 0) {
					// 차량 없으면 진행
					if(curCarEnv.innerISOccupier == 'x') {
						isStopped = false;
					}
					
					// 자신의 주행방향과 일치하지 않으면 정지
					else if(curCarEnv.innerISOccupier != cRoute) {
						isStopped = true;
						break;
					}
				}
				
				// 남쪽 방향 이미 통과한 신호 받지 않음
				if (cRoute == 's') {
					if (p.y - sig[i].getLocation().y > 0) {
						isStopped = false;
						break;
					}
				}

				// 북쪽 방향 이미 통과한 신호 받지 않음
				else if (cRoute == 'n') {
					if (p.y - sig[i].getLocation().y < 0) {
						isStopped = false;
						break;
					}
				}

				// 서쪽 방향 이미 통과한 신호는 받지 않음
				else if (cRoute == 'w') {
					if (p.x - sig[i].getLocation().x < 0) {
						isStopped = false;
						break;
					}
				}

				// 동쪽 방향 이미 통과한 신호는 받지 않음
				else if (cRoute == 'e') {
					if (p.x - sig[i].getLocation().x > 0) {
						isStopped = false;
						break;
					}
				}

				// 우회전 처리 (바로 통과)
				if (cRoute == 'e' && nRoute == 's') {
					isStopped = false;
					break;
				}

				if (cRoute == 'w' && nRoute == 'n') {
					isStopped = false;
					break;
				}

				if (cRoute == 's' && nRoute == 'w') {
					isStopped = false;
					break;
				}

				if (cRoute == 'n' && nRoute == 'e') {
					isStopped = false;
					break;
				}
				
				/////////////////////////////////////////

				// 좌회전 예외 (직진 신호 켜지면 진행)
				if (cRoute == 'e' && nRoute == 'n') {
					if (sig[i].getSigStat(nRoute) == 'g') {
						isStopped = true;
						break;
					}
				}

				if (cRoute == 'w' && nRoute == 's') {
					if (sig[i].getSigStat(nRoute) == 'g') {
						isStopped = true;
						break;
					}
				}

				if (cRoute == 's' && nRoute == 'e') {
					if (sig[i].getSigStat(nRoute) == 'g') {
						isStopped = true;
						break;
					}
				}

				if (cRoute == 'n' && nRoute == 'w') {
					if (sig[i].getSigStat(nRoute) == 'g') {
						isStopped = true;
						break;
					}
				}
				
				// 다음 경로 신호가 빨간불이면 정지
				if (sig[i].getSigStat(nRoute) == 'r') {
					isStopped = true;

					// 직좌신호 
					if (sig[i].getSigStat(cRoute) == 'g') {
						isStopped = false;
						break;
					}

					// 교차로 내부 진입시 진행
					if (Math.abs(sig[i].getLocation().x - p.x) < 17 && Math.abs(sig[i].getLocation().y - p.y) < 17) {
						isStopped = false;
						break;
					}

					break;
				}

				// 다음 신호 초록불이면 진행
				else if (sig[i].getSigStat(nRoute) == 'g')
					isStopped = false;

				break;
			}
		}
	}

	// 방향 변경
	public void directionChange(char cRoute, char nRoute, Point p) {
		
		// 우회전 이동 (북 -> 동)
		if (cRoute == 'n' && nRoute == 'e') {
			for (int i = 0; i < 7; i++) {

				//System.out.println("북 -> 동");
				if (i < 3)
					p.y -= 4;

				else
					p.x += 3;

				move(p.x, p.y);

				try {
					sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		// 우회전 이동 (서 -> 북)
		else if (cRoute == 'w' && nRoute == 'n') {
			for (int i = 0; i < 7; i++) {
				//System.out.println("서 -> 북");
				if (i < 3)
					p.x -= 4;

				else
					p.y -= 3;

				move(p.x, p.y);

				try {
					sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		// 우회전 이동 (동 -> 남)
		else if (cRoute == 'e' && nRoute == 's') {
			for (int i = 0; i < 4; i++) {
				//System.out.println("동 -> 남");
				if(i == 0)
					p.x += 1;
				
				p.y += 3;

				move(p.x, p.y);

				try {
					sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		// 우회전 이동 (남 -> 서)
		else if (cRoute == 's' && nRoute == 'w') {
			for (int i = 0; i < 4; i++) {
				//System.out.println("남 -> 서");
				if (i == 0)
					p.y += 1;

				else
					p.x -= 3;

				move(p.x, p.y);

				try {
					sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		// 좌회전 이동 (북 -> 서)
		else if (cRoute == 'n' && nRoute == 'w') {
			for (int i = 0; i < 12; i++) {
				//System.out.println("북 -> 서");
				if (i < 6)
					p.y -= 3;

				else {
					p.x -= 3;
					p.y -= 2;
				}

				move(p.x, p.y);

				try {
					sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		// 좌회전 이동 (서 -> 남)
		else if (cRoute == 'w' && nRoute == 's') {
			for (int i = 0; i < 12; i++) {
				//System.out.println("서 -> 남");
				if (i < 6)
					p.x -= 3;

				else {
					p.x -= 2;
					p.y += 3;
				}

				move(p.x, p.y);

				try {
					sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		// 좌회전 이동 (동 -> 북)
		else if (cRoute == 'e' && nRoute == 'n') {
			for (int i = 0; i < 8; i++) {
				//System.out.println("동 -> 북");
				if (i == 0)
					p.x += 3;
				
				if (i == 1)
					p.x += 4;

				else {
					p.x += 2;
					p.y -= 3;
				}

				move(p.x, p.y);

				try {
					sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		// 좌회전 이동 (남 -> 동)
		else if (cRoute == 's' && nRoute == 'e') {
			for (int i = 0; i < 8; i++) {
				//System.out.println("남 -> 동");
				if (i == 0) 
					p.y += 3;
				
				if (i == 1)
					p.y += 4;

				else {
					p.x += 3;
					p.y += 2;
				}

				move(p.x, p.y);

				try {
					sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		// 교차로 빠져 나왔을때 신호
		crd.recvInnerPassSignal(this);
		isChecked = true;
		// isPassed = false;
	}

	// 스레드 실행
	public void run() {
		// 테스팅용 고정 y값

		// 속도 증가 주기 1초
		m_timer.schedule(m_task, 0, 1000);
		// 서버 데이터 송신 주기 2초
		send_timer.schedule(send_task, 0, 2000);
		
		while (true) {
			for (int i = 0; i < 30;) {
				// 매 루프마다 서버로 보낼 차량 데이터 업데이트
				carInfo = getCarStat(route[i], p);
				
				// 정지 여부 초기값
				isStopped = false;

				
				if (route[i] == 'e') {
					if (frontCar == null || (frontCar.getPosition().x - p.x) > 20 || (frontCar.getPosition().x - p.x) < -20) {

						if (i < 29)
							requestSig(sig, route[i], route[i + 1], p);

						if (isStopped == true) {
							move(p.x, p.y);
							speed = 0;
							// isChecked = true;
						}

						else
							p.x += speed;
		
					}

					else if (frontCar != null && (frontCar.getPosition().x - p.x) <= 20 && (frontCar.getPosition().x - p.x) >= 0) {
						// System.out.println("e방향 앞차 존재");
						isStopped = true;
						speed = 0;
						move(p.x, p.y);
					}

					try {
						Thread.sleep(100);

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				else if (route[i] == 'w') {
					if (frontCar == null || (frontCar.getPosition().x - p.x) < -20 ||  (frontCar.getPosition().x - p.x) > 20) {

						if (i < 29)
							requestSig(sig, route[i], route[i + 1], p);

						if (isStopped == true) {
							move(p.x, p.y);
							speed = 0;
							// isChecked = true;
						}

						else
							p.x -= speed;
					}

					else if (frontCar != null && (frontCar.getPosition().x - p.x) >= -20 && (frontCar.getPosition().x - p.x) <= 0) {
						isStopped = true;
						speed = 0;
						move(p.x, p.y);
					}

					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				else if (route[i] == 's') {

					if (frontCar == null || (frontCar.getPosition().y - p.y) > 20 || (frontCar.getPosition().y - p.y) < -20) {

						if (i < 29)
							requestSig(sig, route[i], route[i + 1], p);

						if (isStopped == true) {
							move(p.x, p.y);
							speed = 0;
							// isChecked = true;
						}

						else
							p.y += speed;

					}

					else if ((frontCar != null) && (frontCar.getPosition().y - p.y) <= 20 && (frontCar.getPosition().y - p.y) >= 0) {
						isStopped = true;
						speed = 0;
						move(p.x, p.y);
					}

					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				else if (route[i] == 'n') {
					if (frontCar == null || (frontCar.getPosition().y - p.y) < -20 ||  (frontCar.getPosition().y - p.y) > 20) {

						if (i < 29)
							requestSig(sig, route[i], route[i + 1], p);
							
						if (isStopped == true) {
							move(p.x, p.y);
							speed = 0;
							// isChecked = true;
						}

						else 
							p.y -= speed;
						
					}

					else if ((frontCar != null) && (frontCar.getPosition().y - p.y) >= -20 && (frontCar.getPosition().y - p.y) <= 0) {
						isStopped = true;
						speed = 0;
						move(p.x, p.y);
					}

					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

				if (p.x > 623 && p.x < 657 && p.y > 343 && p.y < 377) {

					if (isPassed == false) {
						//System.out.println("1");

						isPassed = true;

						if (isChecked == false) {
							curCarEnv = crd.recvPassSignal(this, route[i + 1]);
							
							frontCar = curCarEnv.frontCar;
							
							if (i < 29) {
								System.out.println("현재 : " + route[i] + "다음 : " + route[i + 1]);
								directionChange(route[i], route[i + 1], p);
							}
						}

						i++;
					}
				}

				else if (p.x > 623 && p.x < 657 && p.y > 720 && p.y < 754) {
					if (isPassed == false) {
						//System.out.println("4");

						isPassed = true;

						if (isChecked == false) {
							curCarEnv = crd.recvPassSignal(this, route[i + 1]);
						
							frontCar = curCarEnv.frontCar;
						
							if (i < 29) {
								System.out.println("현재 : " + route[i] + "다음 : " + route[i + 1]);
								directionChange(route[i], route[i + 1], p);
							}
						}

						i++;
					}
				}

				else if (p.x > 1280 && p.x < 1314 && p.y > 343 && p.y < 377) {
					if (isPassed == false) {
						//System.out.println("2");

						isPassed = true;

						if (isChecked == false) {
							curCarEnv = crd.recvPassSignal(this, route[i + 1]);
							
							frontCar = curCarEnv.frontCar;
							
							if (i < 29) {
								System.out.println("현재 : " + route[i] + "다음 : " + route[i + 1]);
								directionChange(route[i], route[i + 1], p);
							}
						}

						i++;
					}
				}

				else if (p.x > 1280 && p.x < 1314 && p.y > 720 && p.y < 754) {
					if (isPassed == false) {
						//System.out.println("3");

						isPassed = true;

						if (isChecked == false) {
							curCarEnv = crd.recvPassSignal(this, route[i + 1]);

							frontCar = curCarEnv.frontCar;
							
							if (i < 29) {
								System.out.println("현재 : " + route[i] + "다음 : " + route[i + 1]);
								directionChange(route[i], route[i + 1], p);
							}
						}

						i++;
					}
				}

				else {
					isPassed = false;
					isChecked = false;
				}

				if (i >= 1) {
					if (p.x <= 15 || p.y <= 15 || p.x >= 1900 || p.y >= 1060) {
						crd.deregisterCar(this);
						System.out.println("목적지 도착");
						isFinished = true;
						sendSocket.setCarInfo(getCarStat(route[i], p));
						m_timer.cancel();
						send_timer.cancel();
						return;
					}
				}
			}
		}
	}
}