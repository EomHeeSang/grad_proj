package simulation;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;

public class Road extends JFrame {
	private static final long serialVersionUID = 1L;

	private BufferStrategy bs;
	private ArrayList <Car> cars = new ArrayList <Car>();
	private Car tmpCar;
	private Car c;
	private CrossRoadData crd;
	private Signal []signals = new Signal[9];
	private int numbers_car;
	double random;
	private Point point;
	private Image offScreenImage;
	private Graphics offScreen;
	private SendSocket sendSocket;

	public Road() {
		crd = new CrossRoadData();
	
		setSize(1920, 1080);
		setTitle("An Empty Frame");
		getContentPane().setBackground(Color.lightGray);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(null);
		
		numbers_car = 0;
	
		makeSignal();
		
		this.addKeyListener(new KeyListener() {
			public void keyPressed(KeyEvent e) {
				//space bar = 32
				if(e.getKeyCode() == 32) {
					Random random = new Random();
					char[] direction = { 'e', 'w', 's', 'n' };
					char[] route = new char[30];
					char tmpRoute;

					int start = 0;
					int finish = 0;
					
					start = random.nextInt(8) + 1;
					
					while (start == finish)
						finish = random.nextInt(8) + 1;

					switch (start) {
					case 1:
					case 2:
						route[0] = 's';
						break;
					case 3:
					case 4:
						route[0] = 'w';
						break;
					case 5:
					case 6:
						route[0] = 'n';
						break;
					case 7:
					case 8:
						route[0] = 'e';
						break;
					}

					// 두번째 방향부터 랜덤
					for (int i = 1; i < 30; i++) {
						tmpRoute = direction[random.nextInt(4)];
						
						switch(tmpRoute) {
						case 'e':
							if(route[i-1] == 'w') {
								i--;
								continue;
							}
							route[i] = tmpRoute;
							break;
						case 'w':
							if(route[i-1] == 'e') {
								i--;
								continue;
							}
							route[i] = tmpRoute;
							break;
						case 's':
							if(route[i-1] == 'n') {
								i--;
								continue;
							}
							route[i] = tmpRoute;
							break;
						case 'n':
							if(route[i-1] == 's') {
								i--;
								continue;
							}
							route[i] = tmpRoute;
							break;
						}
					}
					
					getCarInfo(start, finish, route);
					
					// 차 출발지, 목적지 포인트 랜덤 생성 
					// makeCar((int)(random*12)+1, (int)(random*12)+1);
					getContentPane().setBackground(Color.BLUE);
				}
			}

			@Override
			public void keyTyped(KeyEvent keyevent) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void keyReleased(KeyEvent keyevent) {
				// TODO Auto-generated method stub
				
			}
		});
	
		setVisible(true);
		
		createBufferStrategy(1);
		createBufferStrategy(2);
	}

	void getCarInfo(int start, int finish, char[] route) {
		// 소켓 통신으로 수신한 차량 생성 데이터정보를 바탕으로 차량 생성 
		makeCar(start, finish, route);
	}
	
	private void makeCar(int start, int finish, char[] route) {
		c = new Car(numbers_car, start, finish, route, signals, crd);
		cars.add(c);
		c.start();
		numbers_car++;
	}
	/*
	private void removeCar(Car[] cars) {
		for(int i=0; i<cars.length; i++) {
			if (cars[i].getPosition() == cars[i].isFinished())
				cars[i] = null;
		}
	}*/
	
	private void makeSignal(){
		for(int i=0;i<4;i++){
			if(i<2){
				signals[i] = new Signal(new Point (640*(i+1)+17*i, 360));
			}
			else{
				signals[i] = new Signal(new Point (640*(i%2+1)+17*(i%2), 737));
			}
			signals[i].start();
		}
	}
	private void paintingjob(Graphics g){
		int blockw, blockh;
		blockw = this.getWidth()/6;
		blockh = this.getHeight()/6;
		
		g.clearRect(0, 0, 1920, 1080);

		g.setColor(new Color(153,204,102));
		
		// 잔디 좌
		g.fillRect(0, 0, 623, 343);
		g.fillRect(0, 377, 623, 343);
		g.fillRect(0, 754, 623, 343);
		
		// 잔디 중
		g.fillRect(657, 0, 623, 343);
		g.fillRect(657, 377, 623, 343);
		g.fillRect(657, 754, 623, 343);
		
		// 잔디 우
		g.fillRect(1314, 0, 623, 343);
		g.fillRect(1314, 377, 623, 343);
		g.fillRect(1314, 754, 623, 343);
		
		g.setColor(Color.YELLOW); // 중앙선
		
		// 좌 수직
		g.fillRect(638, 0, 4, 343);
		g.fillRect(638, 377, 4, 343);
		g.fillRect(638, 754, 4, 343);
		
		// 우 수직
		g.fillRect(1295, 0, 4, 343);
		g.fillRect(1295, 377, 4, 343);
		g.fillRect(1295, 754, 4, 343);
		
		// 좌 수평
		g.fillRect(0, 358, 623, 4);
		g.fillRect(0, 735, 623, 4);
		
		// 중 수평
		g.fillRect(657, 358, 623, 4);
		g.fillRect(657, 735, 623, 4);
		
		// 우 수평
		g.fillRect(1314, 358, 623, 4);
		g.fillRect(1314, 735, 623, 4);
		
		//traffic signal drawing
	    for(int i=0;i<4;i++){
	    	g.setColor(Color.BLUE);
	    	switch(signals[i].getSigStat('n')){
	    	case 'g':
	    		g.setColor(Color.GREEN);
	    		g.fillRect(signals[i].getLocation().x-17, signals[i].getLocation().y-17, 34, 5);
	            break;
            case 'l':
	         case 'r':
	        	 g.setColor(Color.RED);
	        	 g.fillRect(signals[i].getLocation().x-17, signals[i].getLocation().y-17, 34, 5);
	        	break;
        	default:
        		break;
	    	}
	    	switch(signals[i].getSigStat('e')){
	    	case 'g':
	    		g.setColor(Color.GREEN);
	    		g.fillRect(signals[i].getLocation().x+12, signals[i].getLocation().y-17, 5, 34);
	            break;
            case 'l':
	         case 'r':
	        	 g.setColor(Color.RED);
	        	 g.fillRect(signals[i].getLocation().x+12, signals[i].getLocation().y-17, 5, 34);
	        	break;
        	default:
        		break;
	    	}
	    	switch(signals[i].getSigStat('s')){
	    	case 'g':
	    		g.setColor(Color.GREEN);
	    		g.fillRect(signals[i].getLocation().x-17, signals[i].getLocation().y+17, 34, 5);
	            break;
            case 'l':
	         case 'r':
	        	 g.setColor(Color.RED);
	        	 g.fillRect(signals[i].getLocation().x-17, signals[i].getLocation().y+17, 34, 5);
	        	break;
        	default:
        		break;
	    	}
	    	switch(signals[i].getSigStat('w')){
	    	case 'g':
	    		g.setColor(Color.GREEN);
	    		g.fillRect(signals[i].getLocation().x-17, signals[i].getLocation().y-17, 5, 34);
	            break;
            case 'l':
	        case 'r':
	        	 g.setColor(Color.RED);
	        	 g.fillRect(signals[i].getLocation().x-17, signals[i].getLocation().y-17, 5, 34);
	        	break;
        	default:
        		break;
	    	}
	    }

		g.setColor(Color.RED);
		
		for (int i = 0; i < cars.size(); i++) {
			if(cars.get(i).isFinished() == true) {
				cars.remove(i);
				System.gc();
			}
		}
		
		int total = cars.size();
		
		for (int j = 0; j < total; j++) {
			Point p;
			p = cars.get(j).getPosition();
			g.fillOval(p.x, p.y, 10, 10);	
		}
	}
	@Override public void paint(Graphics g) {
		//super.paint(g);

		Graphics2D g2 = (Graphics2D)getBufferStrategy().getDrawGraphics();
		paintingjob(g2);
		this.getBufferStrategy().show();
	}
	
	
	public static void main(String[] args) {
		Road m = new Road();
		//ReceiveSocket rs = new ReceiveSocket(m);
		
		//rs.start();
	
		while (true){
			m.repaint();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}


